package com.example.moblie_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {
    RadioButton shouse,sfacility,stransport,sstaff,sprocess;
    TextView shinfo,sfinfo,stinfo,ssinfo,spinfo;
    EditText ecom;
    Button submit,snext;
    String section;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        this.setTitle("Compliant Page");

        shinfo = (TextView) findViewById(R.id.txtsHouseinfo);
        sfinfo = (TextView) findViewById(R.id.txtsFacilitiesinfo);
        stinfo = (TextView) findViewById(R.id.txtsTransportationinfo);
        ssinfo = (TextView) findViewById(R.id.txtsStaffinfo);
        spinfo = (TextView) findViewById(R.id.txtsProcessesinfo);

        shouse=(RadioButton) findViewById(R.id.rdshouse);
        sfacility=(RadioButton) findViewById(R.id.rdsfacility);
        stransport=(RadioButton) findViewById(R.id.rdstransport);
        sstaff=(RadioButton) findViewById(R.id.rdsstaff);
        sprocess=(RadioButton) findViewById(R.id.rdsprocess);
        ecom=(EditText) findViewById(R.id.edtscom);
        submit=(Button) findViewById(R.id.btnsubmit);
        snext=(Button) findViewById(R.id.btnlogout);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String com=ecom.getText().toString();



                if (com.equals("")){
                    Toast.makeText(HomeActivity.this, "Please enter an Announcement!", Toast.LENGTH_SHORT).show();
                }
                else if (shouse.isChecked()==false&&sfacility.isChecked()==false&&stransport.isChecked()==false&&sstaff.isChecked()==false&&sprocess.isChecked()==false) {
                    Toast.makeText(HomeActivity.this, "Please select a Section!", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (shouse.isChecked()) {
                        String sh1 = shinfo.getText().toString();
                        shinfo.setText(com+"\n"+sh1);
                        ecom.setText("");
                        Toast.makeText(HomeActivity.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    } else if (sfacility.isChecked()) {
                        String sh2 = sfinfo.getText().toString();
                        sfinfo.setText(com+"\n"+sh2);
                        ecom.setText("");
                        Toast.makeText(HomeActivity.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    } else if (stransport.isChecked()) {
                        String sh3 = stinfo.getText().toString();
                        stinfo.setText(com+"\n"+sh3);
                        ecom.setText("");
                        Toast.makeText(HomeActivity.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    } else if (sstaff.isChecked()) {
                        String sh4 = ssinfo.getText().toString();
                        ssinfo.setText(com+"\n"+sh4);
                        ecom.setText("");
                        Toast.makeText(HomeActivity.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    } else if (sprocess.isChecked()) {
                        String sh5 = spinfo.getText().toString();
                        spinfo.setText(com+"\n"+sh5);
                        ecom.setText("");
                        Toast.makeText(HomeActivity.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        snext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}