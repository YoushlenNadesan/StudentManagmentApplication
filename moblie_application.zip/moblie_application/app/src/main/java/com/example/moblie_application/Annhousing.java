package com.example.moblie_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;

public class Annhousing extends AppCompatActivity {
    ListView list;
    ArrayList<String> items;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_annhousing);
        list = (ListView) findViewById(R.id.aphousing);
        items = new ArrayList<>();
        items.add("Apple");
        items.add("Banana");
        items.add("Orange");


        adapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items);
        Intent intent1 = getIntent();
        String hinfo = intent1.getStringExtra("homeannounce");
        addItem(hinfo);
    }

    public void addItem(String i){
        items.add(i);
        list.setAdapter(adapter);
    }

}