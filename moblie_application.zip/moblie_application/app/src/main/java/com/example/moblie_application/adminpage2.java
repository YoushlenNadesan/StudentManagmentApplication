package com.example.moblie_application;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class adminpage2 extends AppCompatActivity {

    RadioButton house, facility, transport, staff, process;
    EditText eannounce;
    Button submit, anext;
    TextView ahinfo, afinfo, atinfo, asinfo, apinfo,hinfo,sinfo,ssec;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminpage2);

        this.setTitle("Announcement Page");


        house = (RadioButton) findViewById(R.id.rdhouse);
        facility = (RadioButton) findViewById(R.id.rdfacility);
        transport = (RadioButton) findViewById(R.id.rdtransport);
        staff = (RadioButton) findViewById(R.id.rdstaff);
        process = (RadioButton) findViewById(R.id.rdprocess);
        eannounce = (EditText) findViewById(R.id.edtannounce);
        submit = (Button) findViewById(R.id.btnadd);
        anext = (Button) findViewById(R.id.btnanext1);

        ahinfo = (TextView) findViewById(R.id.txtHouseinfo);
        afinfo = (TextView) findViewById(R.id.txtFacilitiesinfo);
        atinfo = (TextView) findViewById(R.id.txtTransportationinfo);
        asinfo = (TextView) findViewById(R.id.txtStaffinfo);
        apinfo = (TextView) findViewById(R.id.txtProcessesinfo);

        hinfo=(TextView) findViewById(R.id.asa);
        sinfo=(TextView) findViewById(R.id.ainfo);
        ssec=(TextView) findViewById(R.id.sect);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ann = eannounce.getText().toString();

                if (ann.equals("")) {
                    Toast.makeText(adminpage2.this, "Please enter an Announcement!", Toast.LENGTH_SHORT).show();
                } else if (house.isChecked() == false && facility.isChecked() == false && transport.isChecked() == false && staff.isChecked() == false && process.isChecked() == false) {
                    Toast.makeText(adminpage2.this, "Please select a Section!", Toast.LENGTH_SHORT).show();
                } else {
                    if (house.isChecked()) {
                        String ch1 = ahinfo.getText().toString();
                        ahinfo.setText(ann + "\n" + ch1);
                        eannounce.setText("");
                        Toast.makeText(adminpage2.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    } else if (facility.isChecked()) {
                        String ch2 = afinfo.getText().toString();
                        afinfo.setText(ann + "\n" + ch2);
                        eannounce.setText("");
                        Toast.makeText(adminpage2.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    } else if (transport.isChecked()) {
                        String ch3 = atinfo.getText().toString();
                        atinfo.setText(ann + "\n" + ch3);
                        eannounce.setText("");
                        Toast.makeText(adminpage2.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    } else if (staff.isChecked()) {
                        String ch4 = asinfo.getText().toString();
                        asinfo.setText(ann + "\n" + ch4);
                        eannounce.setText("");
                        Toast.makeText(adminpage2.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    } else if (process.isChecked()) {
                        String ch5 = apinfo.getText().toString();
                        apinfo.setText(ann + "\n" + ch5);
                        eannounce.setText("");
                        Toast.makeText(adminpage2.this, "Announcement Uploaded!", Toast.LENGTH_SHORT).show();
                    }


                }

            }
        });

        anext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);

            }
        });
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("house", ahinfo.getText().toString());
        savedInstanceState.putString("Facility", afinfo.getText().toString());
        savedInstanceState.putString("Transport", atinfo.getText().toString());
        savedInstanceState.putString("Staff", asinfo.getText().toString());
        savedInstanceState.putString("Processes", apinfo.getText().toString());
    }

    @Override
    public void onRestoreInstanceState(@Nullable Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        ahinfo.setText(savedInstanceState.getString("house"));
        afinfo.setText(savedInstanceState.getString("Facility"));
        atinfo.setText(savedInstanceState.getString("Transport"));
        asinfo.setText(savedInstanceState.getString("Staff"));
        apinfo.setText(savedInstanceState.getString("Processes"));
        }

}