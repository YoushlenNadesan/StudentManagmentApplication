package com.example.moblie_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;


public class Adminpage3 extends AppCompatActivity {
    TextView ahinfo,afinfo,atinfo,asinfo,apinfo;
    RadioButton house,facility,transport,staff,process;
    Button snext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminpage3);

        this.setTitle("Announcement Page");

        ahinfo = (TextView) findViewById(R.id.txtHouseinfo);
        afinfo = (TextView) findViewById(R.id.txtFacilitiesinfo);
        atinfo = (TextView) findViewById(R.id.txtTransportationinfo);
        asinfo = (TextView) findViewById(R.id.txtStaffinfo);
        apinfo = (TextView) findViewById(R.id.txtProcessesinfo);
        snext = (Button) findViewById(R.id.btnsnext1);

        house=(RadioButton) findViewById(R.id.rdhouse);
        facility=(RadioButton) findViewById(R.id.rdfacility);
        transport=(RadioButton) findViewById(R.id.rdtransport);
        staff=(RadioButton) findViewById(R.id.rdstaff);
        process=(RadioButton) findViewById(R.id.rdprocess);



            Intent intent1 = getIntent();
            String hinfo = intent1.getStringExtra("homeannounce");
            String copyh1 = ahinfo.getText().toString();
            ahinfo.setText(hinfo+"\n"+copyh1);


            Intent intent2 = getIntent();
            String finfo = intent2.getStringExtra("facilityannounce");
            String copyh2 = afinfo.getText().toString();
            afinfo.setText(finfo+"\n"+copyh2);

            Intent intent3 = getIntent();
            String tinfo = intent3.getStringExtra("transportannounce");
            String copyh3 = atinfo.getText().toString();
            atinfo.setText(tinfo+"\n"+copyh3);

            Intent intent4 = getIntent();
            String sinfo = intent4.getStringExtra("staffannounce");
            String copyh4 = asinfo.getText().toString();
            asinfo.setText(sinfo+"\n"+copyh4);

            Intent intent5 = getIntent();
            String pinfo = intent5.getStringExtra("processannounce");
            String copyh5 = apinfo.getText().toString();
            apinfo.setText(pinfo+"\n"+copyh5);

            snext.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = getIntent();
                    String n = intent.getStringExtra("homeannounce");

                    if (n=="1"){
                        Intent intent6 = new Intent(getApplicationContext(), HomeActivity2.class);
                        startActivity(intent6);
                    }
                    else {
                        Intent intent7 = new Intent(getApplicationContext(), HomeActivity.class);
                        startActivity(intent7);
                    }
                }
            });

    }
}